#/bin/bash

sudo apt update                               
sudo apt install nodejs npm -y

sudo apt install -y chromium libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libxss1 libxcomposite1 libxdamage1 libxrandr2 libgbm1 libasound2 libpangocairo-1.0-0 libgtk-3-0 libxshmfence1


npm install whatsapp-web.js qrcode-terminal puppeteer

npm init -y                                          
npm install whatsapp-web.js qrcode-terminal puppeteer


 npm audit fix

node index.js


